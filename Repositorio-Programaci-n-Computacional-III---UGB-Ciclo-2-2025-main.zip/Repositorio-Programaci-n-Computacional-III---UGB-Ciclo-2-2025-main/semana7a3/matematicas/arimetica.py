def suma(n1,n2):
    return n1+n2