from matematicas.arimetica import suma
from matematicas.geometria import area_tri

print(suma(2,3))

print(area_tri(5,10))
