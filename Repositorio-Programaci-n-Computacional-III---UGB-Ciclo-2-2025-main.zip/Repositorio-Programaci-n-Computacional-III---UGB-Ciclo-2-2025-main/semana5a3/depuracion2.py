def operacion(n1,n2):
    breakpoint()
    return n1+n2

n1 = int(input("Escribe un numero: "))
n2 = int(input("Escribe otro numero: "))
print(f"{n1} + {n2} = {operacion(n1,n2)}")