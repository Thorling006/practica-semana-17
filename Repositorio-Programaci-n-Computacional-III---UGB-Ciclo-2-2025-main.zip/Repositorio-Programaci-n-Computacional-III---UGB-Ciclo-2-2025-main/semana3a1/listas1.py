frutas = ["manzana","naranja","pera","uva","guineo"]

print(frutas[1])

        #    0       1       2      3      4      5        6
nombres = ["juan","maria","luis","angel","ana","luisa","fernando"]
#            -7     -6      -5     -4      -3    -2       -1
print(nombres[4])
print(nombres[-1])
print(nombres[2:5])


colores = ["rojo","verde","azul","morado","amarillo","rosado"]

print(colores[1:3])
print(colores[2:])
print(colores[:5])
print(colores[2:-2])
print(colores[:])
print(colores)