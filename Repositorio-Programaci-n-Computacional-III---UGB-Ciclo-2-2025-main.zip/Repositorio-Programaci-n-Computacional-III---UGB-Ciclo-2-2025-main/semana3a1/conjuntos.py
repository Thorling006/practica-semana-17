numeros = {2,20,10,6,9,40,40}
print(numeros)

numeros.add(25)
print(numeros)

