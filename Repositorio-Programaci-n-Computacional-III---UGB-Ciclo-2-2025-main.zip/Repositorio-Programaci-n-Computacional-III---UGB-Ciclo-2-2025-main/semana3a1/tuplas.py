precios = (0.20,1.15,5.25,0.99,40.15)

#precios[1]=0.20

print(precios[1])