numeros = range(10)
for i in numeros:
    print(i)

estudiantes = ["ana","juan","luis","maria","pedro"]

contador = 1
for estudiante in estudiantes:
    print(f"{contador}-{estudiante} ")
    contador+=1

numeros = [20,10,2,5,7,2]
for num in numeros:
    print(num**2)

#Imprimir la tabla del 1 al 10 que el usuario nos indique
#Ej: 1*5 = 5
#    2*5 = 10 etc..