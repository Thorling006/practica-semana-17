nombres = ["ana","juan","pedro"]
nombres2 = ["maria","pepito","luis"]

print(nombres+nombres2)
print(nombres*8)

print("julio" in nombres)
print("julio" not in nombres)

print("maria" in nombres2)
print("maria" not in nombres2)