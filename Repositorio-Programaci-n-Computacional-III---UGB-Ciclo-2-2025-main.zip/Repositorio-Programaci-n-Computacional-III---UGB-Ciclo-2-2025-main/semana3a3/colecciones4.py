conjunto = {"a","b","c","d","e","e"}

print(conjunto)
conjunto.add("f")
print(conjunto)