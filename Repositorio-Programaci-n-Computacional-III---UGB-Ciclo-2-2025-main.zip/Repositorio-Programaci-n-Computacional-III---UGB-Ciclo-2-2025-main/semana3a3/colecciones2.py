estudiantes = ["ana","juan","pedro"]
print(estudiantes)

estudiantes.append("luis")
print(estudiantes)

estudiantes.insert(1,"maria")
print(estudiantes)

estudiantes.remove("pedro")
print(estudiantes)

estudiantes.pop(0)
print(estudiantes)
estudiantes.sort()
print(estudiantes)

numeros = [34,9,12,0,1,54]
numeros.sort()
print(numeros)

print(numeros.index(1))

print(estudiantes[0])
estudiantes[0] = "Mario"
print(estudiantes)
