          #0   1   2     3
listado = [20,10,"Hola",True]

print(listado[2])

          #0,1,2,3,4,5,6
numeros = [1,2,3,4,5,6,7]

     #        0       1       2       3        4        5          6
frutas = ["manzana","pera","sandia","melon","guineos","zapote","naranjas"]
#agarrar los elementos desde sandia hasta zapote
#como me quedaria el print?
print(frutas[2:5]) 
print(frutas[2:])
print(frutas[:4])
print(frutas[1:-1])
print(frutas[:])
print(len(frutas))

nombres = ["juan","ana","pedro"]
apellidos = ["perez","sanchez","hernandez"]
print(nombres+apellidos)
print(nombres*2)


listado2 = [2,4,6,8,10]
print(1 in listado2)
print(10 in listado2)

print(1 not in listado2)
print(10 not in listado2)