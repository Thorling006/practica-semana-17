colores = ("azul","amarillo","verde","rojo")

print(colores[0])
#colores[0] = "morado"
#colores.append("morado")
#colores.insert("morado")
#colores.pop(0)
#colores.remove("azul")
print(colores[1:3])
