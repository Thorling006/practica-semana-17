def suma(a,b):
    return a+b

print(suma(1,2))

def multi(a,b):
    return a*b