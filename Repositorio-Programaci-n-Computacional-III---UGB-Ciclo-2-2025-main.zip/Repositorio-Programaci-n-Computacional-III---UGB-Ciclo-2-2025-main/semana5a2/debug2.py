def sumar_lista(numeros):
    breakpoint()
    total = 0
    for n in numeros:
        total += n
    return total

print(sumar_lista([2,4,5,6,9,10]))