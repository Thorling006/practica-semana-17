        #   0       1       2      3
listado = ["ana","maria","juan","luis"]
        #  -4      -3      -2      -1

print(listado[2])
print(listado[-1])

        #       0        1       2        3         4       5       6
listado2 = ["manzana","pera","guineos","sandias","melon","uvas","fresas"]
       #       -7       -6     -5        -4        -3       -2      -1
print(listado2[0:2])
#hacer un splice que vaya desde guineos hasta uvas
print(listado2[2:6])
print(listado2[3:-2])
print(listado2[1:])
print(listado2[:3])
print(listado2[:])
print(listado2)