conjunto = {5,10,11,20,4,6}
conjunto2 = {"a","b","c","d","e"}

print(conjunto)
print(conjunto2)

#print(conjunto[0])
conjunto.add(20)
print(conjunto)
