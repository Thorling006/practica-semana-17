lista1 = ["ana","juan","pedro","luis"]
lista2 = ["hernandez","sanchez","martinez"]

#Concatenacion +
print(lista1+lista2)
#Replicacion *
print(lista1*2)

print("maria" in lista1)
print("pedro" in lista1)

print("maria" not in lista1)
print("pedro" not in lista1)