#Estructura if
n1 = 20
n2 = 10

if n1>n2:
    print(f"El mayor es {n1}")
elif n2<n1:
    print(f"El mayor es {n2}")
else:
    print(f"Los numeros son iguales")