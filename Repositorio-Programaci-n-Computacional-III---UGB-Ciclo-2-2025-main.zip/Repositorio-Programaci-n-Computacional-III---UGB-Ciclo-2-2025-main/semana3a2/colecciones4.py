sabores = ("fresa","vanilla","chocolate","menta","chicle")

#sabores.append("napolitano")
#sabores.insert(1,"napolitano")
#sabores.pop(2)
#sabores.remove("vainilla")

print(sabores[0])
#sabores[1] = "napolitano"
