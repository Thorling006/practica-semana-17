def area_tri(base,altura):
    return (base*altura)/2