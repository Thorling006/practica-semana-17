from operaciones.arimeticas import sumar
from operaciones.geometricas import area_tri

print(sumar(1,2))
print(area_tri(20,10))