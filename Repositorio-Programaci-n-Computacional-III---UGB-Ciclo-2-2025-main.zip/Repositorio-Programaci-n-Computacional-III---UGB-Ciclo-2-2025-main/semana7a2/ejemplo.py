from matematicas.arimetica import sumar
from matematicas.geometria import area_tri

print(sumar(10,2))
print(area_tri(10,20))